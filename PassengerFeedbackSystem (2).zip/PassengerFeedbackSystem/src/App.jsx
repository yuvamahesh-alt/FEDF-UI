import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import AdminRoute from './components/AdminRoute.jsx';
import Home from './pages/Home.jsx';
import Login from './pages/Login.jsx';
import Signup from './pages/Signup.jsx';
import AdminLogin from './pages/AdminLogin.jsx';
import FeedbackForm from './pages/FeedbackForm.jsx';
import FeedbackHistory from './pages/FeedbackHistory.jsx';
import Analytics from './pages/Analytics.jsx';
import AdminReview from './pages/AdminReview.jsx';
import ExportCSV from './pages/ExportCSV.jsx';

export default function App() {
  return (
    <div className="app-wrapper">
      <Navbar />
      <main className="main-content">
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/admin-login" element={<AdminLogin />} />

          {/* Passenger-only routes — require user session */}
          <Route element={<ProtectedRoute />}>
            <Route path="/feedback"  element={<FeedbackForm />} />
            <Route path="/history"   element={<FeedbackHistory />} />
            <Route path="/analytics" element={<Analytics />} />
          </Route>

          {/* Admin-only routes — require admin session */}
          <Route element={<AdminRoute />}>
            <Route path="/admin"  element={<AdminReview />} />
            <Route path="/export" element={<ExportCSV />} />
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
