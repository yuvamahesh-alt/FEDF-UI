// utils/storage.js — LocalStorage helpers for users, feedback, and session

const KEYS = {
  USERS:         'pfs_users',
  FEEDBACK:      'pfs_feedback',
  SESSION:       'pfs_session',
  ADMIN_SESSION: 'pfs_admin_session',
};

/* ─── Hardcoded Admin Credentials ───────────────────────────
   In a real app these would live server-side. Here they are
   fixed so no sign-up flow is needed for the admin portal.
   Credentials: admin@pfs.com / Admin@123
────────────────────────────────────────────────────────────── */
export const ADMIN_CREDENTIALS = [
  {
    id:       'admin-001',
    fullName: 'Super Admin',
    email:    'admin@pfs.com',
    password: 'Admin@123',
    role:     'admin',
  },
  {
    id:       'admin-002',
    fullName: 'Ops Manager',
    email:    'ops@pfs.com',
    password: 'Ops@2024',
    role:     'admin',
  },
];

/* ─── Users ─────────────────────────────────────────────── */

export const getUsers = () => {
  try {
    return JSON.parse(localStorage.getItem(KEYS.USERS)) || [];
  } catch {
    return [];
  }
};

export const saveUser = (user) => {
  const users = getUsers();
  users.push(user);
  localStorage.setItem(KEYS.USERS, JSON.stringify(users));
};

export const findUserByEmail = (email) =>
  getUsers().find((u) => u.email.toLowerCase() === email.toLowerCase());

/* ─── Session ────────────────────────────────────────────── */

export const getSession = () => {
  try {
    return JSON.parse(localStorage.getItem(KEYS.SESSION));
  } catch {
    return null;
  }
};

export const setSession = (user) =>
  localStorage.setItem(KEYS.SESSION, JSON.stringify(user));

export const clearSession = () =>
  localStorage.removeItem(KEYS.SESSION);

/* ─── Admin Session ──────────────────────────────────────── */

export const getAdminSession = () => {
  try {
    return JSON.parse(localStorage.getItem(KEYS.ADMIN_SESSION));
  } catch {
    return null;
  }
};

export const setAdminSession = (admin) =>
  localStorage.setItem(KEYS.ADMIN_SESSION, JSON.stringify(admin));

export const clearAdminSession = () =>
  localStorage.removeItem(KEYS.ADMIN_SESSION);

export const findAdminByCredentials = (email, password) =>
  ADMIN_CREDENTIALS.find(
    (a) => a.email.toLowerCase() === email.toLowerCase() && a.password === password
  ) || null;

/* ─── Feedback ───────────────────────────────────────────── */

export const getFeedback = () => {
  try {
    return JSON.parse(localStorage.getItem(KEYS.FEEDBACK)) || [];
  } catch {
    return [];
  }
};

export const saveFeedback = (entry) => {
  const list = getFeedback();
  list.unshift(entry); // newest first
  localStorage.setItem(KEYS.FEEDBACK, JSON.stringify(list));
};

export const updateFeedback = (id, updates) => {
  const list = getFeedback().map((f) =>
    f.id === id ? { ...f, ...updates } : f
  );
  localStorage.setItem(KEYS.FEEDBACK, JSON.stringify(list));
};

export const deleteFeedbackById = (id) => {
  const list = getFeedback().filter((f) => f.id !== id);
  localStorage.setItem(KEYS.FEEDBACK, JSON.stringify(list));
};
