// utils/sentiment.js — Auto-calculate sentiment from ratings

/**
 * Calculates average of ratings array and returns a sentiment label.
 * Positive  → avg >= 4.0
 * Neutral   → avg >= 2.5
 * Negative  → avg < 2.5
 */
export const calculateSentiment = ({ cabinCrew, food, cleanliness, punctuality }) => {
  const ratings = [
    Number(cabinCrew),
    Number(food),
    Number(cleanliness),
    Number(punctuality),
  ];
  const avg = ratings.reduce((a, b) => a + b, 0) / ratings.length;

  if (avg >= 4.0) return 'Positive';
  if (avg >= 2.5) return 'Neutral';
  return 'Negative';
};

export const sentimentColor = (sentiment) => {
  switch (sentiment) {
    case 'Positive': return '#22c55e';
    case 'Neutral':  return '#f59e0b';
    case 'Negative': return '#ef4444';
    default:         return '#94a3b8';
  }
};

export const sentimentBadgeClass = (sentiment) => {
  switch (sentiment) {
    case 'Positive': return 'badge badge-positive';
    case 'Neutral':  return 'badge badge-neutral';
    case 'Negative': return 'badge badge-negative';
    default:         return 'badge';
  }
};
