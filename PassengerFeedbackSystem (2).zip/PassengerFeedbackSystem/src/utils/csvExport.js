// utils/csvExport.js — Convert feedback array to downloadable CSV

const HEADERS = [
  'ID',
  'Passenger Name',
  'Flight Number',
  'Travel Date',
  'Cabin Crew Rating',
  'Food Rating',
  'Cleanliness Rating',
  'Punctuality Rating',
  'Average Rating',
  'Sentiment',
  'Status',
  'Comments',
  'Submitted At',
];

const escape = (val) => {
  const str = String(val ?? '');
  // Wrap in quotes if contains comma, quote, or newline
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
};

export const exportToCSV = (feedbackList) => {
  if (!feedbackList || feedbackList.length === 0) return;

  const avgRating = (f) => {
    const vals = [f.cabinCrew, f.food, f.cleanliness, f.punctuality].map(Number);
    return (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(2);
  };

  const rows = feedbackList.map((f) => [
    f.id,
    f.passengerName,
    f.flightNumber,
    f.travelDate,
    f.cabinCrew,
    f.food,
    f.cleanliness,
    f.punctuality,
    avgRating(f),
    f.sentiment,
    f.status,
    f.comments,
    new Date(f.submittedAt).toLocaleString(),
  ].map(escape).join(','));

  const csvContent = [HEADERS.join(','), ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = 'passenger_feedback_export.csv';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
