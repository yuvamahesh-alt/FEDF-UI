// utils/validation.js — Field-level validation helpers

export const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email.trim()) return 'Email is required.';
  if (!re.test(email)) return 'Enter a valid email address.';
  return '';
};

export const validatePassword = (pw) => {
  if (!pw) return 'Password is required.';
  if (pw.length < 6) return 'Password must be at least 6 characters.';
  return '';
};

export const validateConfirmPassword = (pw, cpw) => {
  if (!cpw) return 'Please confirm your password.';
  if (pw !== cpw) return 'Passwords do not match.';
  return '';
};

export const validateFullName = (name) => {
  if (!name.trim()) return 'Full name is required.';
  if (name.trim().length < 2) return 'Name must be at least 2 characters.';
  return '';
};

export const validateMobile = (mobile) => {
  const re = /^[6-9]\d{9}$/; // Indian mobile format
  if (!mobile.trim()) return 'Mobile number is required.';
  if (!re.test(mobile.replace(/\s/g, ''))) return 'Enter a valid 10-digit mobile number.';
  return '';
};

export const validateFlightNumber = (fn) => {
  if (!fn.trim()) return 'Flight number is required.';
  if (!/^[A-Za-z0-9]{2,8}$/.test(fn.trim())) return 'Enter a valid flight number (e.g. AI202).';
  return '';
};

export const validateTravelDate = (date) => {
  if (!date) return 'Travel date is required.';
  const d = new Date(date);
  if (isNaN(d.getTime())) return 'Enter a valid date.';
  return '';
};

export const validateComments = (c) => {
  if (!c.trim()) return 'Comments are required.';
  if (c.trim().length < 10) return 'Comments must be at least 10 characters.';
  return '';
};
