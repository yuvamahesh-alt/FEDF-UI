// components/Footer.jsx
import { Link } from 'react-router-dom';
import './Footer.css';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-brand">
          <span className="footer-icon">✈</span>
          <span className="footer-title">PassengerFeedback</span>
          <p className="footer-tagline">Elevating every journey through your voice.</p>
        </div>

        <div className="footer-links">
          <div className="footer-col">
            <h4>Platform</h4>
            <Link to="/feedback">Submit Feedback</Link>
            <Link to="/history">Feedback History</Link>
            <Link to="/analytics">Analytics</Link>
          </div>
          <div className="footer-col">
            <h4>Management</h4>
            <Link to="/admin">Admin Review</Link>
            <Link to="/export">Export CSV</Link>
          </div>
          <div className="footer-col">
            <h4>Account</h4>
            <Link to="/login">Login</Link>
            <Link to="/signup">Sign Up</Link>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {year} PassengerFeedback System. Built for excellence in aviation service.</p>
      </div>
    </footer>
  );
}
