// components/ProtectedRoute.jsx
import { Navigate, Outlet } from 'react-router-dom';
import { getSession } from '../utils/storage.js';

/**
 * Wraps private routes. Redirects to /login when no session exists.
 */
export default function ProtectedRoute() {
  const session = getSession();
  return session ? <Outlet /> : <Navigate to="/login" replace />;
}
