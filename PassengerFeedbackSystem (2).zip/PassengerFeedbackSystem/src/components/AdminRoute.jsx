// components/AdminRoute.jsx
// Guards routes that require an active admin session.
// If no admin is logged in, redirects to /admin-login.

import { Navigate, Outlet } from 'react-router-dom';
import { getAdminSession } from '../utils/storage.js';

export default function AdminRoute() {
  const admin = getAdminSession();
  return admin ? <Outlet /> : <Navigate to="/admin-login" replace />;
}
