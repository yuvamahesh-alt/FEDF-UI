// components/Navbar.jsx
// Shows different nav links depending on whether a user or admin is logged in.
// A normal user NEVER sees admin links. An admin sees only admin links.

import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { getSession, clearSession, getAdminSession, clearAdminSession } from '../utils/storage.js';
import './Navbar.css';

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate  = useNavigate();
  const user      = getSession();
  const admin     = getAdminSession();

  const handleUserLogout = () => {
    clearSession();
    setMenuOpen(false);
    navigate('/login');
  };

  const handleAdminLogout = () => {
    clearAdminSession();
    setMenuOpen(false);
    navigate('/admin-login');
  };

  const close = () => setMenuOpen(false);
  const nl = (path) => ({ isActive }) => isActive ? 'nav-link active' : 'nav-link';

  return (
    <header className="navbar">
      <div className="nav-inner">
        {/* Brand */}
        <Link to="/" className="nav-brand" onClick={close}>
          <span className="brand-icon">✈</span>
          <span className="brand-text">PassengerFeedback</span>
          {admin && <span className="admin-pill">Admin</span>}
        </Link>

        {/* Hamburger */}
        <button
          className={`hamburger ${menuOpen ? 'open' : ''}`}
          onClick={() => setMenuOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          <span /><span /><span />
        </button>

        {/* ── ADMIN nav ── */}
        {admin && (
          <nav className={`nav-links ${menuOpen ? 'open' : ''}`}>
            <NavLink to="/" end onClick={close} className={nl('/')}>Home</NavLink>
            <NavLink to="/admin"  onClick={close} className={nl('/admin')}>Review Feedback</NavLink>
            <NavLink to="/export" onClick={close} className={nl('/export')}>Export CSV</NavLink>
            <div className="nav-user">
              <span className="user-greeting admin-greeting">🛡️ {admin.fullName.split(' ')[0]}</span>
              <button className="btn btn-sm btn-danger-outline" onClick={handleAdminLogout}>Logout</button>
            </div>
          </nav>
        )}

        {/* ── USER nav ── */}
        {!admin && (
          <nav className={`nav-links ${menuOpen ? 'open' : ''}`}>
            <NavLink to="/" end onClick={close} className={nl('/')}>Home</NavLink>

            {user ? (
              <>
                <NavLink to="/feedback"  onClick={close} className={nl('/feedback')}>Submit Feedback</NavLink>
                <NavLink to="/history"   onClick={close} className={nl('/history')}>History</NavLink>
                <NavLink to="/analytics" onClick={close} className={nl('/analytics')}>Analytics</NavLink>
                <div className="nav-user">
                  <span className="user-greeting">👤 {user.fullName.split(' ')[0]}</span>
                  <button className="btn btn-sm btn-secondary" onClick={handleUserLogout}>Logout</button>
                </div>
              </>
            ) : (
              <div className="nav-auth">
                <NavLink to="/login"       onClick={close} className="btn btn-sm btn-secondary">Login</NavLink>
                <NavLink to="/signup"      onClick={close} className="btn btn-sm btn-primary">Sign Up</NavLink>
                <NavLink to="/admin-login" onClick={close} className="btn btn-sm btn-admin-outline">Admin</NavLink>
              </div>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}
