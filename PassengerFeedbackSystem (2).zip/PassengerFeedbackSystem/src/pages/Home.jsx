// pages/Home.jsx
import { Link } from 'react-router-dom';
import { getSession } from '../utils/storage.js';
import './Home.css';

const FEATURES = [
  { icon: '📋', title: 'Submit Feedback', desc: 'Rate cabin crew, food, cleanliness, and punctuality in one streamlined form.' },
  { icon: '📊', title: 'Live Analytics', desc: 'Track sentiment trends, average ratings, and feedback volume in real time.' },
  { icon: '🛡️', title: 'Admin Review', desc: 'Approve, reject, or mark feedback reviewed with a single click.' },
  { icon: '📥', title: 'CSV Export', desc: 'Download all feedback data in CSV format for offline analysis.' },
];

const STATS = [
  { value: '50K+', label: 'Flights Reviewed' },
  { value: '98%', label: 'Satisfaction Rate' },
  { value: '12', label: 'Airlines Onboard' },
  { value: '4.7★', label: 'Average Score' },
];

export default function Home() {
  const user = getSession();

  return (
    <div className="home">
      {/* Hero */}
      <section className="hero">
        <div className="hero-content">
          <p className="hero-eyebrow">✈ Airline Passenger Feedback System</p>
          <h1 className="hero-headline">
            Your Voice Shapes<br />Every Flight
          </h1>
          <p className="hero-sub">
            Share your experience with cabin crew, food, cleanliness, and punctuality.
            Help airlines deliver journeys worth remembering.
          </p>
          <div className="hero-ctas">
            {user ? (
              <>
                <Link to="/feedback" className="btn btn-gold btn-lg">Submit Feedback</Link>
                <Link to="/analytics" className="btn btn-secondary btn-lg" style={{ color: '#fff', borderColor: 'rgba(255,255,255,.4)' }}>View Analytics</Link>
              </>
            ) : (
              <>
                <Link to="/signup" className="btn btn-gold btn-lg">Get Started — Free</Link>
                <Link to="/login" className="btn btn-secondary btn-lg" style={{ color: '#fff', borderColor: 'rgba(255,255,255,.4)' }}>Passenger Login</Link>
              </>
            )}
          </div>
        </div>
        <div className="hero-visual" aria-hidden="true">
          <div className="plane-card">
            <div className="plane-row"><span className="dot green" /> Positive Sentiment</div>
            <div className="plane-row"><span className="dot amber" /> Neutral Sentiment</div>
            <div className="plane-row"><span className="dot red" /> Negative Sentiment</div>
            <div className="plane-divider" />
            <div className="plane-stat">
              <span>Cabin Crew</span>
              <div className="plane-bar"><div className="plane-bar-fill" style={{ width: '88%' }} /></div>
              <strong>4.4</strong>
            </div>
            <div className="plane-stat">
              <span>Food</span>
              <div className="plane-bar"><div className="plane-bar-fill amber" style={{ width: '72%' }} /></div>
              <strong>3.6</strong>
            </div>
            <div className="plane-stat">
              <span>Cleanliness</span>
              <div className="plane-bar"><div className="plane-bar-fill" style={{ width: '80%' }} /></div>
              <strong>4.0</strong>
            </div>
            <div className="plane-stat">
              <span>Punctuality</span>
              <div className="plane-bar"><div className="plane-bar-fill teal" style={{ width: '65%' }} /></div>
              <strong>3.2</strong>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="stats-bar">
        <div className="stats-bar-inner">
          {STATS.map((s) => (
            <div key={s.label} className="stats-bar-item">
              <span className="stats-bar-value">{s.value}</span>
              <span className="stats-bar-label">{s.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="features-section">
        <div className="features-inner">
          <p className="section-eye">What you get</p>
          <h2 className="section-heading">Every tool you need to manage feedback</h2>
          <div className="features-grid">
            {FEATURES.map((f) => (
              <div key={f.title} className="feature-card">
                <div className="feature-icon">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="cta-banner">
        <div className="cta-inner">
          <h2>Ready to improve your flight experience?</h2>
          <p>Join thousands of passengers making aviation better.</p>
          {!user && (
            <Link to="/signup" className="btn btn-gold btn-lg">Create Your Account</Link>
          )}
          {user && (
            <Link to="/feedback" className="btn btn-gold btn-lg">Submit a Feedback</Link>
          )}
        </div>
      </section>
    </div>
  );
}
