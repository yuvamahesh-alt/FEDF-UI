// pages/FeedbackForm.jsx
import { useState } from 'react';
import { getSession, saveFeedback } from '../utils/storage.js';
import {
  validateFlightNumber, validateTravelDate, validateComments,
} from '../utils/validation.js';
import { calculateSentiment } from '../utils/sentiment.js';
import './FeedbackForm.css';

const RATINGS = [
  { key: 'cabinCrew',   label: 'Cabin Crew', icon: '👩‍✈️' },
  { key: 'food',        label: 'Food & Beverage', icon: '🍽️' },
  { key: 'cleanliness', label: 'Cleanliness', icon: '✨' },
  { key: 'punctuality', label: 'Punctuality', icon: '⏱️' },
];

function StarRating({ value, onChange, name }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="stars" role="group" aria-label={`${name} rating`}>
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          type="button"
          className={`star-btn ${s <= (hover || value) ? 'active' : ''}`}
          onClick={() => onChange(s)}
          onMouseEnter={() => setHover(s)}
          onMouseLeave={() => setHover(0)}
          aria-label={`${s} star${s > 1 ? 's' : ''}`}
        >
          ★
        </button>
      ))}
      {value > 0 && <span className="star-label">{value}/5</span>}
    </div>
  );
}

const INITIAL = {
  passengerName: '',
  flightNumber: '',
  travelDate: '',
  cabinCrew: 0,
  food: 0,
  cleanliness: 0,
  punctuality: 0,
  comments: '',
};

export default function FeedbackForm() {
  const user = getSession();
  const [form, setForm]     = useState({ ...INITIAL, passengerName: user?.fullName || '' });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((er) => ({ ...er, [name]: '' }));
    setSuccess('');
  };

  const setRating = (key, val) => {
    setForm((f) => ({ ...f, [key]: val }));
    setErrors((er) => ({ ...er, [key]: '' }));
  };

  const validate = () => {
    const e = {};
    if (!form.passengerName.trim()) e.passengerName = 'Passenger name is required.';
    e.flightNumber = validateFlightNumber(form.flightNumber);
    e.travelDate   = validateTravelDate(form.travelDate);
    if (form.cabinCrew   === 0) e.cabinCrew   = 'Please rate cabin crew.';
    if (form.food        === 0) e.food        = 'Please rate food.';
    if (form.cleanliness === 0) e.cleanliness = 'Please rate cleanliness.';
    if (form.punctuality === 0) e.punctuality = 'Please rate punctuality.';
    e.comments = validateComments(form.comments);
    // Remove empty string errors
    return Object.fromEntries(Object.entries(e).filter(([, v]) => v));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setSubmitting(true);
    setTimeout(() => {
      const entry = {
        ...form,
        id:          crypto.randomUUID(),
        sentiment:   calculateSentiment(form),
        status:      'Pending',
        submittedAt: new Date().toISOString(),
        submittedBy: user?.email || 'guest',
      };
      saveFeedback(entry);
      setSuccess(`✅ Feedback submitted! Sentiment detected: ${entry.sentiment}`);
      setForm({ ...INITIAL, passengerName: user?.fullName || '' });
      setErrors({});
      setSubmitting(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 700);
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="page-narrow">
      <h1 className="page-title">Submit Feedback</h1>
      <p className="page-sub">Tell us about your recent flight experience</p>

      {success && <div className="alert alert-success">{success}</div>}

      <form onSubmit={handleSubmit} noValidate className="feedback-form card">
        {/* Basic info */}
        <h2 className="section-sub-heading">Flight Details</h2>

        <div className="form-group">
          <label className="form-label" htmlFor="passengerName">Passenger Name</label>
          <input
            id="passengerName" name="passengerName" type="text"
            className={`form-input ${errors.passengerName ? 'error' : ''}`}
            placeholder="Full name as per ticket"
            value={form.passengerName}
            onChange={handleChange}
          />
          {errors.passengerName && <p className="form-error">{errors.passengerName}</p>}
        </div>

        <div className="form-row-2">
          <div className="form-group">
            <label className="form-label" htmlFor="flightNumber">Flight Number</label>
            <input
              id="flightNumber" name="flightNumber" type="text"
              className={`form-input ${errors.flightNumber ? 'error' : ''}`}
              placeholder="e.g. AI202"
              value={form.flightNumber}
              onChange={handleChange}
              style={{ textTransform: 'uppercase' }}
            />
            {errors.flightNumber && <p className="form-error">{errors.flightNumber}</p>}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="travelDate">Travel Date</label>
            <input
              id="travelDate" name="travelDate" type="date"
              className={`form-input ${errors.travelDate ? 'error' : ''}`}
              value={form.travelDate}
              onChange={handleChange}
              max={today}
            />
            {errors.travelDate && <p className="form-error">{errors.travelDate}</p>}
          </div>
        </div>

        <hr className="divider" />
        <h2 className="section-sub-heading">Ratings</h2>

        {RATINGS.map(({ key, label, icon }) => (
          <div className="form-group rating-group" key={key}>
            <label className="form-label">{icon} {label}</label>
            <StarRating value={form[key]} onChange={(v) => setRating(key, v)} name={label} />
            {errors[key] && <p className="form-error">{errors[key]}</p>}
          </div>
        ))}

        <hr className="divider" />

        <div className="form-group">
          <label className="form-label" htmlFor="comments">Comments</label>
          <textarea
            id="comments" name="comments"
            className={`form-textarea ${errors.comments ? 'error' : ''}`}
            placeholder="Share your experience in detail (min 10 characters)…"
            value={form.comments}
            onChange={handleChange}
            rows={4}
          />
          {errors.comments && <p className="form-error">{errors.comments}</p>}
        </div>

        <button type="submit" className="btn btn-primary btn-lg btn-block" disabled={submitting}>
          {submitting ? 'Submitting…' : '✈ Submit Feedback'}
        </button>
      </form>
    </div>
  );
}
