// pages/Analytics.jsx
import { useMemo } from 'react';
import { getFeedback } from '../utils/storage.js';
import './Analytics.css';

function ProgressBar({ value, max = 5, color }) {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <div className="progress-bar-bg">
      <div className="progress-bar-fill" style={{ width: `${pct}%`, background: color || 'var(--cobalt)' }} />
    </div>
  );
}

const RATING_KEYS = [
  { key: 'cabinCrew',   label: 'Cabin Crew',       icon: '👩‍✈️', color: '#1a56db' },
  { key: 'food',        label: 'Food & Beverage',   icon: '🍽️',  color: '#0ea5e9' },
  { key: 'cleanliness', label: 'Cleanliness',        icon: '✨',  color: '#8b5cf6' },
  { key: 'punctuality', label: 'Punctuality',        icon: '⏱️', color: '#f59e0b' },
];

export default function Analytics() {
  const feedback = getFeedback();
  const total = feedback.length;

  const stats = useMemo(() => {
    if (!total) return null;

    const avgOf = (key) => {
      const sum = feedback.reduce((a, f) => a + Number(f[key]), 0);
      return (sum / total).toFixed(2);
    };

    const count = (sentiment) => feedback.filter((f) => f.sentiment === sentiment).length;
    const statusCount = (s) => feedback.filter((f) => f.status === s).length;

    return {
      avgCabinCrew:   avgOf('cabinCrew'),
      avgFood:        avgOf('food'),
      avgCleanliness: avgOf('cleanliness'),
      avgPunctuality: avgOf('punctuality'),
      positive: count('Positive'),
      neutral:  count('Neutral'),
      negative: count('Negative'),
      pending:  statusCount('Pending'),
      approved: statusCount('Approved'),
      rejected: statusCount('Rejected'),
      reviewed: statusCount('Reviewed'),
    };
  }, [feedback, total]);

  if (!total) {
    return (
      <div className="page">
        <h1 className="page-title">Analytics Dashboard</h1>
        <p className="page-sub">No feedback data available yet.</p>
        <div className="empty-state">
          <div className="empty-icon">📊</div>
          <p>Submit some feedback to see analytics appear here.</p>
        </div>
      </div>
    );
  }

  const overallAvg = (
    (Number(stats.avgCabinCrew) + Number(stats.avgFood) + Number(stats.avgCleanliness) + Number(stats.avgPunctuality)) / 4
  ).toFixed(2);

  const sentPct = (n) => ((n / total) * 100).toFixed(1);

  return (
    <div className="page">
      <h1 className="page-title">Analytics Dashboard</h1>
      <p className="page-sub">Real-time insights across all submitted feedback</p>

      {/* Top stat cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">📋</div>
          <div className="stat-value">{total}</div>
          <div className="stat-label">Total Submissions</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">⭐</div>
          <div className="stat-value">{overallAvg}</div>
          <div className="stat-label">Overall Avg Rating</div>
        </div>
        <div className="stat-card" style={{ borderTop: '3px solid #22c55e' }}>
          <div className="stat-icon">😊</div>
          <div className="stat-value" style={{ color: '#16a34a' }}>{stats.positive}</div>
          <div className="stat-label">Positive Feedback</div>
        </div>
        <div className="stat-card" style={{ borderTop: '3px solid #f59e0b' }}>
          <div className="stat-icon">😐</div>
          <div className="stat-value" style={{ color: '#b45309' }}>{stats.neutral}</div>
          <div className="stat-label">Neutral Feedback</div>
        </div>
        <div className="stat-card" style={{ borderTop: '3px solid #ef4444' }}>
          <div className="stat-icon">😞</div>
          <div className="stat-value" style={{ color: '#dc2626' }}>{stats.negative}</div>
          <div className="stat-label">Negative Feedback</div>
        </div>
      </div>

      <div className="analytics-grid">
        {/* Ratings breakdown */}
        <div className="card">
          <h3 className="card-title">Average Ratings by Category</h3>
          <div className="ratings-list">
            {RATING_KEYS.map(({ key, label, icon, color }) => {
              const avg = Number(stats[`avg${key.charAt(0).toUpperCase() + key.slice(1)}`]);
              return (
                <div key={key} className="rating-row">
                  <span className="rating-label">{icon} {label}</span>
                  <div className="rating-bar-wrap">
                    <ProgressBar value={avg} color={color} />
                  </div>
                  <span className="rating-val" style={{ color }}>{avg.toFixed(2)}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sentiment distribution */}
        <div className="card">
          <h3 className="card-title">Sentiment Distribution</h3>
          <div className="sentiment-list">
            {[
              { label: 'Positive', count: stats.positive, pct: sentPct(stats.positive), color: '#22c55e', bg: '#dcfce7' },
              { label: 'Neutral',  count: stats.neutral,  pct: sentPct(stats.neutral),  color: '#f59e0b', bg: '#fef3c7' },
              { label: 'Negative', count: stats.negative, pct: sentPct(stats.negative), color: '#ef4444', bg: '#fee2e2' },
            ].map((s) => (
              <div key={s.label} className="sentiment-row">
                <div className="sentiment-top">
                  <span className="sentiment-name">{s.label}</span>
                  <span className="sentiment-stats">
                    <strong>{s.count}</strong>
                    <span className="text-muted"> ({s.pct}%)</span>
                  </span>
                </div>
                <div className="progress-bar-bg">
                  <div className="progress-bar-fill" style={{ width: `${s.pct}%`, background: s.color }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Review status */}
        <div className="card">
          <h3 className="card-title">Review Status Overview</h3>
          <div className="status-grid-inner">
            {[
              { label: 'Pending',  count: stats.pending,  cls: 'badge-pending' },
              { label: 'Approved', count: stats.approved, cls: 'badge-approved' },
              { label: 'Rejected', count: stats.rejected, cls: 'badge-rejected' },
              { label: 'Reviewed', count: stats.reviewed, cls: 'badge-reviewed' },
            ].map((s) => (
              <div key={s.label} className="status-box">
                <span className={`badge ${s.cls}`}>{s.label}</span>
                <strong className="status-count">{s.count}</strong>
                <span className="status-pct">{sentPct(s.count)}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
