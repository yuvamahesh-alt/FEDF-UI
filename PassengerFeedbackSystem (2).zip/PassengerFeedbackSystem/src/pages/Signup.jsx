// pages/Signup.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { findUserByEmail, saveUser, setSession } from '../utils/storage.js';
import {
  validateFullName, validateEmail, validateMobile,
  validatePassword, validateConfirmPassword,
} from '../utils/validation.js';
import './Auth.css';

export default function Signup() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: '', email: '', mobile: '', password: '', confirmPassword: '',
  });
  const [errors, setErrors] = useState({});
  const [showPw, setShowPw]   = useState(false);
  const [showCpw, setShowCpw] = useState(false);
  const [serverErr, setServerErr] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((er) => ({ ...er, [name]: '' }));
    setServerErr('');
  };

  const validate = () => ({
    fullName:        validateFullName(form.fullName),
    email:           validateEmail(form.email),
    mobile:          validateMobile(form.mobile),
    password:        validatePassword(form.password),
    confirmPassword: validateConfirmPassword(form.password, form.confirmPassword),
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.values(errs).some(Boolean)) { setErrors(errs); return; }

    setLoading(true);
    setTimeout(() => {
      if (findUserByEmail(form.email)) {
        setServerErr('An account with this email already exists.');
        setLoading(false);
        return;
      }
      const user = {
        id:       crypto.randomUUID(),
        fullName: form.fullName.trim(),
        email:    form.email.trim().toLowerCase(),
        mobile:   form.mobile.trim(),
        password: form.password,
        createdAt: new Date().toISOString(),
      };
      saveUser(user);
      setSession(user);
      navigate('/');
    }, 600);
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-header">
          <span className="auth-icon">✈</span>
          <h1>Create account</h1>
          <p>Join PassengerFeedback — it's free</p>
        </div>

        {serverErr && <div className="alert alert-error">{serverErr}</div>}

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label" htmlFor="fullName">Full Name</label>
            <input
              id="fullName" name="fullName" type="text"
              className={`form-input ${errors.fullName ? 'error' : ''}`}
              placeholder="Arjun Sharma"
              value={form.fullName}
              onChange={handleChange}
              autoComplete="name"
            />
            {errors.fullName && <p className="form-error">{errors.fullName}</p>}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="email">Email Address</label>
            <input
              id="email" name="email" type="email"
              className={`form-input ${errors.email ? 'error' : ''}`}
              placeholder="arjun@example.com"
              value={form.email}
              onChange={handleChange}
              autoComplete="email"
            />
            {errors.email && <p className="form-error">{errors.email}</p>}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="mobile">Mobile Number</label>
            <input
              id="mobile" name="mobile" type="tel"
              className={`form-input ${errors.mobile ? 'error' : ''}`}
              placeholder="9876543210"
              value={form.mobile}
              onChange={handleChange}
              autoComplete="tel"
              maxLength={10}
            />
            {errors.mobile && <p className="form-error">{errors.mobile}</p>}
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label" htmlFor="password">Password</label>
              <div className="input-wrap">
                <input
                  id="password" name="password" type={showPw ? 'text' : 'password'}
                  className={`form-input ${errors.password ? 'error' : ''}`}
                  placeholder="Min 6 chars"
                  value={form.password}
                  onChange={handleChange}
                  autoComplete="new-password"
                />
                <button type="button" className="eye-btn" onClick={() => setShowPw((s) => !s)} aria-label="Toggle password">
                  {showPw ? '🙈' : '👁️'}
                </button>
              </div>
              {errors.password && <p className="form-error">{errors.password}</p>}
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="confirmPassword">Confirm Password</label>
              <div className="input-wrap">
                <input
                  id="confirmPassword" name="confirmPassword" type={showCpw ? 'text' : 'password'}
                  className={`form-input ${errors.confirmPassword ? 'error' : ''}`}
                  placeholder="Repeat password"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  autoComplete="new-password"
                />
                <button type="button" className="eye-btn" onClick={() => setShowCpw((s) => !s)} aria-label="Toggle confirm password">
                  {showCpw ? '🙈' : '👁️'}
                </button>
              </div>
              {errors.confirmPassword && <p className="form-error">{errors.confirmPassword}</p>}
            </div>
          </div>

          <button type="submit" className="btn btn-primary btn-lg btn-block" disabled={loading}>
            {loading ? 'Creating account…' : 'Create Account'}
          </button>
        </form>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Sign In</Link>
        </p>
      </div>
    </div>
  );
}
