// pages/AdminLogin.jsx
// Dedicated admin portal login — completely separate from passenger login.
// Uses hardcoded admin credentials from storage.js.

import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { findAdminByCredentials, setAdminSession, getAdminSession } from '../utils/storage.js';
import { validateEmail, validatePassword } from '../utils/validation.js';
import './AdminLogin.css';

export default function AdminLogin() {
  const navigate = useNavigate();

  // If already logged in as admin, redirect straight to /admin
  if (getAdminSession()) {
    navigate('/admin', { replace: true });
    return null;
  }

  const [form, setForm]      = useState({ email: '', password: '' });
  const [errors, setErrors]  = useState({});
  const [showPw, setShowPw]  = useState(false);
  const [authErr, setAuthErr] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((er) => ({ ...er, [name]: '' }));
    setAuthErr('');
  };

  const validate = () => ({
    email:    validateEmail(form.email),
    password: validatePassword(form.password),
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.values(errs).some(Boolean)) { setErrors(errs); return; }

    setLoading(true);
    // Small artificial delay for UX
    setTimeout(() => {
      const admin = findAdminByCredentials(form.email, form.password);
      if (!admin) {
        setAuthErr('Invalid admin credentials. Access denied.');
        setLoading(false);
        return;
      }
      setAdminSession(admin);
      navigate('/admin');
    }, 700);
  };

  return (
    <div className="admin-auth-page">
      {/* Left panel — branding */}
      <div className="admin-auth-left">
        <div className="admin-auth-brand">
          <span className="admin-auth-icon">🛡️</span>
          <h2>Admin Portal</h2>
          <p>
            Restricted access. This portal is for authorised airline operations staff only.
            Passenger accounts cannot sign in here.
          </p>
        </div>
        <ul className="admin-feature-list">
          <li>✅ Review &amp; moderate all submissions</li>
          <li>✅ Approve, reject, or mark as reviewed</li>
          <li>✅ Export complete feedback dataset</li>
          <li>🔒 No access to passenger accounts</li>
        </ul>
        <p className="admin-demo-hint">
          <strong>Demo credentials</strong><br />
          admin@pfs.com · Admin@123<br />
          <span className="dim">ops@pfs.com · Ops@2024</span>
        </p>
      </div>

      {/* Right panel — form */}
      <div className="admin-auth-right">
        <div className="admin-auth-card">
          <div className="admin-auth-header">
            <span className="admin-badge-icon">🛡️</span>
            <h1>Admin Sign In</h1>
            <p>PassengerFeedback Operations Centre</p>
          </div>

          {authErr && (
            <div className="alert alert-error">
              🚫 {authErr}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label className="form-label" htmlFor="email">Admin Email</label>
              <input
                id="email" name="email" type="email"
                className={`form-input ${errors.email ? 'error' : ''}`}
                placeholder="admin@pfs.com"
                value={form.email}
                onChange={handleChange}
                autoComplete="username"
              />
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="password">Admin Password</label>
              <div className="input-wrap">
                <input
                  id="password" name="password"
                  type={showPw ? 'text' : 'password'}
                  className={`form-input ${errors.password ? 'error' : ''}`}
                  placeholder="Your admin password"
                  value={form.password}
                  onChange={handleChange}
                  autoComplete="current-password"
                />
                <button
                  type="button" className="eye-btn"
                  onClick={() => setShowPw((s) => !s)}
                  aria-label="Toggle password visibility"
                >
                  {showPw ? '🙈' : '👁️'}
                </button>
              </div>
              {errors.password && <p className="form-error">{errors.password}</p>}
            </div>

            <button
              type="submit"
              className="btn btn-admin btn-lg btn-block"
              disabled={loading}
            >
              {loading ? 'Verifying…' : '🔐 Sign In to Admin Portal'}
            </button>
          </form>

          <div className="admin-back-link">
            Not an admin? <Link to="/login">Passenger login →</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
