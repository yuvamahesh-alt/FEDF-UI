// pages/AdminReview.jsx
import { useState, useMemo } from 'react';
import { getFeedback, updateFeedback, getAdminSession } from '../utils/storage.js';
import { sentimentBadgeClass } from '../utils/sentiment.js';
import './AdminReview.css';

const STATUSES = ['Pending', 'Approved', 'Rejected', 'Reviewed'];

const STATUS_BADGE = {
  Pending:  'badge badge-pending',
  Approved: 'badge badge-approved',
  Rejected: 'badge badge-rejected',
  Reviewed: 'badge badge-reviewed',
};

export default function AdminReview() {
  const admin = getAdminSession();
  const [list, setList]         = useState(() => getFeedback());
  const [filterStatus, setFilterStatus] = useState('All');
  const [toast, setToast]       = useState('');

  const filtered = useMemo(() => {
    if (filterStatus === 'All') return list;
    return list.filter((f) => f.status === filterStatus);
  }, [list, filterStatus]);

  const handleStatusChange = (id, newStatus) => {
    updateFeedback(id, { status: newStatus });
    setList(getFeedback());
    setToast(`Status updated to ${newStatus}`);
    setTimeout(() => setToast(''), 2500);
  };

  const avgRating = (f) => {
    const vals = [f.cabinCrew, f.food, f.cleanliness, f.punctuality].map(Number);
    return (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1);
  };

  return (
    <div className="page">
      <div className="admin-identity-strip">
        🛡️ Signed in as admin: <strong>{admin?.fullName}</strong> ({admin?.email})
      </div>
      <h1 className="page-title">Admin Review</h1>
      <p className="page-sub">Review and update the status of all submitted passenger feedback</p>

      {toast && <div className="alert alert-success">{toast}</div>}

      <div className="filter-row">
        <select className="form-select" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
          <option value="All">All Statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <span className="result-count">{filtered.length} record{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🗂️</div>
          <p>{list.length === 0 ? 'No feedback submitted yet.' : 'No records match the selected status.'}</p>
        </div>
      ) : (
        <div className="admin-cards">
          {filtered.map((f) => (
            <div key={f.id} className="admin-card card">
              <div className="admin-card-header">
                <div>
                  <h3 className="admin-passenger">{f.passengerName}</h3>
                  <span className="admin-flight">Flight {f.flightNumber} · {f.travelDate}</span>
                </div>
                <div className="admin-badges">
                  <span className={sentimentBadgeClass(f.sentiment)}>{f.sentiment}</span>
                  <span className={STATUS_BADGE[f.status] || 'badge'}>{f.status}</span>
                </div>
              </div>

              {/* Ratings row */}
              <div className="admin-ratings">
                {[
                  { label: 'Crew', val: f.cabinCrew },
                  { label: 'Food', val: f.food },
                  { label: 'Clean', val: f.cleanliness },
                  { label: 'Punc.', val: f.punctuality },
                ].map((r) => (
                  <div key={r.label} className="mini-rating">
                    <span className="mini-label">{r.label}</span>
                    <span className="mini-stars">{'★'.repeat(Number(r.val))}{'☆'.repeat(5 - Number(r.val))}</span>
                  </div>
                ))}
                <div className="mini-rating">
                  <span className="mini-label">Avg</span>
                  <strong className="mini-avg">⭐ {avgRating(f)}</strong>
                </div>
              </div>

              {/* Comments */}
              {f.comments && (
                <p className="admin-comments">"{f.comments}"</p>
              )}

              {/* Status actions */}
              <div className="admin-actions">
                <span className="admin-actions-label">Change status:</span>
                {STATUSES.map((s) => (
                  <button
                    key={s}
                    className={`btn btn-sm status-btn ${f.status === s ? 'status-btn-active' : ''}`}
                    onClick={() => handleStatusChange(f.id, s)}
                    disabled={f.status === s}
                  >
                    {s}
                  </button>
                ))}
              </div>

              <p className="admin-meta">
                Submitted on {new Date(f.submittedAt).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
