// pages/FeedbackHistory.jsx
import { useState, useMemo } from 'react';
import { getFeedback, deleteFeedbackById } from '../utils/storage.js';
import { sentimentBadgeClass } from '../utils/sentiment.js';
import './FeedbackHistory.css';

const STATUS_CLASS = {
  Pending:  'badge badge-pending',
  Approved: 'badge badge-approved',
  Rejected: 'badge badge-rejected',
  Reviewed: 'badge badge-reviewed',
};

export default function FeedbackHistory() {
  const [list, setList]         = useState(() => getFeedback());
  const [search, setSearch]     = useState('');
  const [sentiment, setSentiment] = useState('All');
  const [toDelete, setToDelete] = useState(null);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return list.filter((f) => {
      const matchQ = !q || f.passengerName.toLowerCase().includes(q) || f.flightNumber.toLowerCase().includes(q);
      const matchS = sentiment === 'All' || f.sentiment === sentiment;
      return matchQ && matchS;
    });
  }, [list, search, sentiment]);

  const confirmDelete = () => {
    deleteFeedbackById(toDelete);
    setList(getFeedback());
    setToDelete(null);
  };

  const avgRating = (f) => {
    const vals = [f.cabinCrew, f.food, f.cleanliness, f.punctuality].map(Number);
    return (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1);
  };

  return (
    <div className="page">
      <h1 className="page-title">Feedback History</h1>
      <p className="page-sub">Browse, search, and manage all submitted feedback</p>

      {/* Filter row */}
      <div className="filter-row">
        <input
          type="text"
          className="form-input"
          placeholder="Search by name or flight…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="form-select" value={sentiment} onChange={(e) => setSentiment(e.target.value)}>
          <option value="All">All Sentiments</option>
          <option value="Positive">Positive</option>
          <option value="Neutral">Neutral</option>
          <option value="Negative">Negative</option>
        </select>
        <span className="result-count">{filtered.length} record{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📭</div>
          <p>{list.length === 0 ? 'No feedback submitted yet.' : 'No records match your search.'}</p>
        </div>
      ) : (
        <div className="card table-wrap" style={{ padding: 0, overflow: 'hidden' }}>
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Passenger</th>
                <th>Flight</th>
                <th>Date</th>
                <th>Avg Rating</th>
                <th>Sentiment</th>
                <th>Status</th>
                <th>Submitted</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((f, i) => (
                <tr key={f.id}>
                  <td className="text-muted">{i + 1}</td>
                  <td><strong>{f.passengerName}</strong></td>
                  <td><code className="flight-code">{f.flightNumber}</code></td>
                  <td>{f.travelDate}</td>
                  <td>
                    <span className="avg-pill">⭐ {avgRating(f)}</span>
                  </td>
                  <td><span className={sentimentBadgeClass(f.sentiment)}>{f.sentiment}</span></td>
                  <td><span className={STATUS_CLASS[f.status] || 'badge'}>{f.status}</span></td>
                  <td className="text-muted text-sm">{new Date(f.submittedAt).toLocaleDateString()}</td>
                  <td>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => setToDelete(f.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Confirm delete modal */}
      {toDelete && (
        <div className="modal-overlay" onClick={() => setToDelete(null)}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <h3>Delete Feedback?</h3>
            <p>This action cannot be undone. The feedback record will be permanently removed.</p>
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setToDelete(null)}>Cancel</button>
              <button className="btn btn-danger"    onClick={confirmDelete}>Yes, Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
