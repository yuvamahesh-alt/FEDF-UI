// pages/ExportCSV.jsx
import { useState } from 'react';
import { getFeedback, getAdminSession } from '../utils/storage.js';
import { exportToCSV } from '../utils/csvExport.js';
import { sentimentBadgeClass } from '../utils/sentiment.js';
import './ExportCSV.css';

export default function ExportCSV() {
  const admin    = getAdminSession();
  const feedback = getFeedback();
  const [exported, setExported] = useState(false);

  const handleExport = () => {
    exportToCSV(feedback);
    setExported(true);
    setTimeout(() => setExported(false), 3000);
  };

  const total    = feedback.length;
  const positive = feedback.filter((f) => f.sentiment === 'Positive').length;
  const neutral  = feedback.filter((f) => f.sentiment === 'Neutral').length;
  const negative = feedback.filter((f) => f.sentiment === 'Negative').length;

  const avgRating = (f) => {
    const vals = [f.cabinCrew, f.food, f.cleanliness, f.punctuality].map(Number);
    return (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1);
  };

  return (
    <div className="page">
      <div className="admin-identity-strip">
        🛡️ Signed in as admin: <strong>{admin?.fullName}</strong> ({admin?.email})
      </div>
      <h1 className="page-title">Export CSV</h1>
      <p className="page-sub">Download all feedback records in CSV format for offline analysis</p>

      {/* Export panel */}
      <div className="card export-panel">
        <div className="export-info">
          <div className="export-icon">📥</div>
          <div>
            <h3>passenger_feedback_export.csv</h3>
            <p>
              Includes all {total} record{total !== 1 ? 's' : ''} with passenger name, flight number, date,
              individual ratings, average rating, sentiment, review status, and comments.
            </p>
          </div>
        </div>

        {exported && (
          <div className="alert alert-success">
            ✅ File downloaded successfully! Check your downloads folder.
          </div>
        )}

        <div className="export-meta">
          <div className="export-stat">
            <span className="export-stat-label">Total Records</span>
            <strong className="export-stat-value">{total}</strong>
          </div>
          <div className="export-stat">
            <span className="export-stat-label">Positive</span>
            <strong className="export-stat-value pos">{positive}</strong>
          </div>
          <div className="export-stat">
            <span className="export-stat-label">Neutral</span>
            <strong className="export-stat-value neu">{neutral}</strong>
          </div>
          <div className="export-stat">
            <span className="export-stat-label">Negative</span>
            <strong className="export-stat-value neg">{negative}</strong>
          </div>
        </div>

        <button
          className="btn btn-primary btn-lg"
          onClick={handleExport}
          disabled={total === 0}
        >
          {total === 0 ? '⚠ No data to export' : '⬇ Download CSV'}
        </button>
        {total === 0 && (
          <p className="export-hint">Submit some feedback first before exporting.</p>
        )}
      </div>

      {/* Preview table */}
      {total > 0 && (
        <div className="card" style={{ marginTop: '1.5rem', padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '1.25rem 1.5rem .75rem' }}>
            <h3 className="card-title" style={{ marginBottom: 0 }}>Preview (latest {Math.min(total, 10)} records)</h3>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Passenger</th>
                  <th>Flight</th>
                  <th>Date</th>
                  <th>Avg Rating</th>
                  <th>Sentiment</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {feedback.slice(0, 10).map((f, i) => (
                  <tr key={f.id}>
                    <td>{i + 1}</td>
                    <td><strong>{f.passengerName}</strong></td>
                    <td><code style={{ background: 'var(--surface-2)', padding: '.1rem .4rem', borderRadius: '4px', fontSize: '.82rem' }}>{f.flightNumber}</code></td>
                    <td>{f.travelDate}</td>
                    <td>⭐ {avgRating(f)}</td>
                    <td><span className={sentimentBadgeClass(f.sentiment)}>{f.sentiment}</span></td>
                    <td>{f.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {total > 10 && (
            <p style={{ padding: '.75rem 1.5rem', fontSize: '.82rem', color: 'var(--text-muted)' }}>
              … and {total - 10} more record{total - 10 !== 1 ? 's' : ''} included in the export.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
